package org.l2j.commons.database;

public interface DAO {
}
