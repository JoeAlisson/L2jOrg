package org.l2j.commons.configuration;

public interface Settings {

    void load(SettingsFile settingsFile);

}