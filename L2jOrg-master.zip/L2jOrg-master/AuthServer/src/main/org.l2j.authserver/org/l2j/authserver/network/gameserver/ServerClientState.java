package org.l2j.authserver.network.gameserver;

public enum ServerClientState {
    CONNECTED,
    AUTHED;
}