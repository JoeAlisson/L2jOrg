package org.l2j.authserver.controller;

public enum AuthResult {
    INVALID_PASSWORD,
    ACCOUNT_BANNED,
    ALREADY_ON_LS,
    ALREADY_ON_GS,
    AUTH_SUCCESS
}
