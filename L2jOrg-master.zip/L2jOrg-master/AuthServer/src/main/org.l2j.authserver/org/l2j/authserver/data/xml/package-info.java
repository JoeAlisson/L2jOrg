//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.3.1-b171012.0423 
// Consulte <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2018.10.08 às 08:08:13 PM BRT 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://la2j.org", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.l2j.authserver.data.xml;
