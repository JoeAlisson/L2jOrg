package org.l2j.authserver.network.client;

public enum AuthClientState {
    CONNECTED,
    AUTHED_GG,
    AUTHED_LOGIN;
}